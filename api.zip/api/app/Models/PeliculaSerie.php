<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PeliculaSerie extends Model
{
    use HasFactory;

    protected $fillable = ['nombre', 'clasificacion', 'fecha_lanzamiento', 'revision_general', 'temporada'];

    public function personajes()
    {
        return $this->hasMany(Personaje::class);
    }
}
