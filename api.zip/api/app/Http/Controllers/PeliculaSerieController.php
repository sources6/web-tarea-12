<?php

namespace App\Http\Controllers;

use App\Models\PeliculaSerie;
use Illuminate\Http\Request;

class PeliculaSerieController extends Controller
{
    public function index()
    {
        return PeliculaSerie::all();
    }

    public function store(Request $request)
    {
        return PeliculaSerie::create($request->all());
    }

    public function show(PeliculaSerie $peliculaSerie)
    {
        return $peliculaSerie;
    }

    public function update(Request $request, PeliculaSerie $peliculaSerie)
    {
        $peliculaSerie->update($request->all());
        return $peliculaSerie;
    }

    public function destroy(PeliculaSerie $peliculaSerie)
    {
        $peliculaSerie->delete();
        return response()->json(null, 204);
    }
}

